(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var livestamp;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['copleykj:livestamp'] = {
  livestamp: livestamp
};

})();

//# sourceMappingURL=copleykj_livestamp.js.map
